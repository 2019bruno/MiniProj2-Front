# MiniProj2-Front (Vue CLI + JWT)

## Setup (Vue CLI)
1. Instalar Node.js e Vue CLI (`npm install -g @vue/cli`)
2. `cd MiniProj2-Front`
3. `npm install`
4. `npm run serve`

## Notes
- A app usa Vue 2 (compatível com Vue CLI 4.x)
- Faz login em /login (p.ex. user criado usando endpoint /auth/register)
- Após login a app guarda o token no localStorage
- A API deve correr em http://localhost:8080
