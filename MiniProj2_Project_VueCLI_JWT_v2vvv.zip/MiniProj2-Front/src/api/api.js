import axios from 'axios';
import store from '../store';

const api = axios.create({
  baseURL: 'http://localhost:8080',
  headers: { 'Content-Type': 'application/json' }
});

// Attach token to requests if present
api.interceptors.request.use(cfg => {
  const token = store.state.token;
  if (token) cfg.headers.Authorization = 'Bearer ' + token;
  return cfg;
});

export default api;
