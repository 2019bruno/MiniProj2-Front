import Vue from 'vue';
import Router from 'vue-router';
import Clientes from '../views/Clientes.vue';
import Consultas from '../views/Consultas.vue';
import Tratamentos from '../views/Tratamentos.vue';
import Login from '../components/Login.vue';

Vue.use(Router);

const router = new Router({
  mode: 'history',
  routes: [
    { path: '/', redirect: '/clientes' },
    { path: '/login', component: Login },
    { path: '/clientes', component: Clientes },
    { path: '/consultas', component: Consultas },
    { path: '/tratamentos', component: Tratamentos },
  ]
});

export default router;
