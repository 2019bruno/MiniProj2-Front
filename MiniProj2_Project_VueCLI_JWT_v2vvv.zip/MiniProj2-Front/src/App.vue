<template>
  <div id="app" style="padding:20px; font-family:Arial, sans-serif;">
    <h1>MiniProj2 - Front (Vue CLI + JWT)</h1>
    <nav style="margin-bottom:12px;">
      <router-link to="/clientes">Clientes</router-link> |
      <router-link to="/consultas">Consultas</router-link> |
      <router-link to="/tratamentos">Tratamentos</router-link> |
      <router-link to="/login">Login</router-link>
      <button v-if="token" @click="logout" style="margin-left:10px;">Logout</button>
    </nav>
    <router-view></router-view>
  </div>
</template>

<script>
import store from './store';

export default {
  computed: {
    token() { return store.state.token; }
  },
  methods: {
    logout() {
      store.commit('clearToken');
      this.$router.push('/login');
    }
  }
}
</script>
