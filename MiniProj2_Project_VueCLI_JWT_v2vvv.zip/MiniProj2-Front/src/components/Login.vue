<template>
  <div>
    <h2>Login</h2>
    <form @submit.prevent="login">
      <input v-model="username" placeholder="username" required />
      <input v-model="password" type="password" placeholder="password" required />
      <button type="submit">Entrar</button>
    </form>
    <p v-if="error" style="color:red">{{ error }}</p>
  </div>
</template>

<script>
import api from '../api/api';
import store from '../store';

export default {
  data() { return { username: '', password: '', error: null }; },
  methods: {
    async login() {
      try {
        const res = await api.post('/auth/login', { username: this.username, password: this.password });
        const token = res.data.token;
        store.commit('setToken', token);
        this.$router.push('/clientes');
      } catch (err) {
        this.error = err.response && err.response.data && err.response.data.error ? err.response.data.error : 'Erro';
      }
    }
  }
}
</script>
