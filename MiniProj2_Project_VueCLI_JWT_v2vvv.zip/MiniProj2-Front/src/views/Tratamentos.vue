<template>
  <div>
    <h2>Tratamentos</h2>

    <form @submit.prevent="criar" style="margin-bottom:12px;">
      <select v-model="novo.consultaId" required>
        <option disabled value="">Selecionar Consulta</option>
        <option v-for="q in consultas" :value="q._id">{{ q.animalId }} — {{ (new Date(q.data)).toLocaleString() }}</option>
      </select>
      <input v-model="novo.tipo" placeholder="Tipo" required />
      <input v-model.number="novo.custo" type="number" placeholder="Custo" />
      <button type="submit">Adicionar Tratamento</button>
    </form>

    <ul>
      <li v-for="t in tratamentos" :key="t._id">
        {{ t.tipo }} — {{ t.custo }} (consulta: {{ t.consultaId }})
        <button @click="remover(t._id)">Remover</button>
      </li>
    </ul>
  </div>
</template>

<script>
import api from '../api/api';

export default {
  data() {
    return {
      tratamentos: [],
      consultas: [],
      novo: { consultaId: '', tipo: '', custo: 0 },
      error: null
    };
  },
  async created() {
    await this.load();
  },
  methods: {
    async load() {
      try {
        const [tRes, qRes] = await Promise.all([api.get('/tratamentos'), api.get('/consultas')]);
        this.tratamentos = tRes.data;
        this.consultas = qRes.data;
      } catch (err) {
        this.error = 'Erro ao carregar (verifica se estás autenticado)';
      }
    },
    async criar() {
      await api.post('/tratamentos', this.novo);
      this.novo = { consultaId: '', tipo: '', custo: 0 };
      await this.load();
    },
    async remover(id) {
      await api.delete(`/tratamentos/${id}`);
      await this.load();
    }
  }
};
</script>
