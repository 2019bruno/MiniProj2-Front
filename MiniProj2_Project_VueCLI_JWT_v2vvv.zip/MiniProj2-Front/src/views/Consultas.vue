<template>
  <div>
    <h2>Consultas</h2>

    <form @submit.prevent="criar" style="margin-bottom:12px;">
      <input v-model="novo.animalId" placeholder="animalId (texto)" required />
      <select v-model="novo.clienteId" required>
        <option disabled value="">Selecionar Cliente</option>
        <option v-for="c in clientes" :value="c._id">{{ c.nome }}</option>
      </select>
      <input v-model="novo.data" type="datetime-local" required />
      <input v-model="novo.descricao" placeholder="Descrição" />
      <button type="submit">Adicionar Consulta</button>
    </form>

    <ul>
      <li v-for="q in consultas" :key="q._id">
        {{ q.animalId }} — {{ q.descricao }} — {{ new Date(q.data).toLocaleString() }}
        <button @click="remover(q._id)">Remover</button>
      </li>
    </ul>
  </div>
</template>

<script>
import api from '../api/api';

export default {
  data() {
    return {
      consultas: [],
      clientes: [],
      novo: { animalId: '', clienteId: '', data: '', descricao: '' },
      error: null
    };
  },
  async created() {
    await this.load();
  },
  methods: {
    async load() {
      try {
        const [cRes, qRes] = await Promise.all([api.get('/clientes'), api.get('/consultas')]);
        this.clientes = cRes.data;
        this.consultas = qRes.data;
      } catch (err) {
        this.error = 'Erro ao carregar (verifica se estás autenticado)';
      }
    },
    async criar() {
      const payload = { ...this.novo, data: new Date(this.novo.data).toISOString() };
      await api.post('/consultas', payload);
      this.novo = { animalId: '', clienteId: '', data: '', descricao: '' };
      await this.load();
    },
    async remover(id) {
      await api.delete(`/consultas/${id}`);
      await this.load();
    }
  }
};
</script>
