<template>
  <div>
    <h2>Clientes</h2>

    <form @submit.prevent="criarCliente" style="margin-bottom:12px;">
      <input v-model="novo.nome" placeholder="Nome" required />
      <input v-model="novo.email" placeholder="Email" required />
      <input v-model="novo.telefone" placeholder="Telefone" />
      <button type="submit">Adicionar</button>
    </form>

    <ul>
      <li v-for="c in clientes" :key="c._id">
        <strong>{{ c.nome }}</strong> — {{ c.email }} — {{ c.telefone }}
        <button @click="remover(c._id)">Remover</button>
      </li>
    </ul>
  </div>
</template>

<script>
import api from '../api/api';

export default {
  data() {
    return {
      clientes: [],
      novo: { nome: '', email: '', telefone: '' },
      error: null
    };
  },
  async created() {
    await this.load();
  },
  methods: {
    async load() {
      try {
        const res = await api.get('/clientes');
        this.clientes = res.data;
      } catch (err) {
        this.error = 'Erro ao carregar (verifica se estás autenticado)';
      }
    },
    async criarCliente() {
      await api.post('/clientes', this.novo);
      this.novo = { nome: '', email: '', telefone: '' };
      await this.load();
    },
    async remover(id) {
      await api.delete(`/clientes/${id}`);
      await this.load();
    }
  }
};
</script>
