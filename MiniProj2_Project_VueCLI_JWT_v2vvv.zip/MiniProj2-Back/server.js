const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const config = require("./config/config");

const clientesRoutes = require("./routes/clientesRoutes");
const consultasRoutes = require("./routes/consultasRoutes");
const tratamentosRoutes = require("./routes/tratamentosRoutes");
const authRoutes = require("./routes/authRoutes");
const animalsRoutes = require("./routes/animalsRoutes");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(config.uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB conectado"))
  .catch(err => console.log("Erro a conectar MongoDB:", err.message));

app.get("/", (req, res) => res.json({ message: "API Animalec - MiniProj2 (exemplo fictício) - com JWT" }));

app.use("/auth", authRoutes);
app.use("/animals", animalsRoutes);
app.use("/clientes", clientesRoutes);
app.use("/consultas", consultasRoutes);
app.use("/tratamentos", tratamentosRoutes);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Back-end a correr em http://localhost:${PORT}`));
