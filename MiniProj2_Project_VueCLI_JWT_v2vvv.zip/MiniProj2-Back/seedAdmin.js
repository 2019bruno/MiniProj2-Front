// Run this once to create default admin user
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const config = require('./config/config');

mongoose.connect(config.uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(async () => {
    console.log('MongoDB conectado para seed');
    const exists = await User.findOne({ username: 'admin' });
    if (exists) {
      console.log('Admin já existe');
      process.exit(0);
    }
    const hash = await bcrypt.hash('admin', 10);
    const u = new User({ username: 'admin', passwordHash: hash, role: 'admin' });
    await u.save();
    console.log('Admin criado: username=admin password=admin');
    process.exit(0);
  })
  .catch(err => {
    console.error('Erro:', err);
    process.exit(1);
  });
