module.exports = {
  jwtSecret: "segredo_super_secreto_muito_forte_2025",
  uri: "mongodb://localhost:27017/test"
};
