const Tratamento = require("../models/Tratamento");

exports.getAll = async (req, res) => {
  try {
    const tratamentos = await Tratamento.find().sort({ createdAt: -1 });
    res.json(tratamentos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getById = async (req, res) => {
  try {
    const tr = await Tratamento.findById(req.params.id);
    if (!tr) return res.status(404).json({ error: "Tratamento não encontrado" });
    res.json(tr);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.create = async (req, res) => {
  try {
    const tr = new Tratamento(req.body);
    await tr.save();
    res.status(201).json(tr);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const tr = await Tratamento.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!tr) return res.status(404).json({ error: "Tratamento não encontrado" });
    res.json(tr);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    await Tratamento.findByIdAndDelete(req.params.id);
    res.json({ message: "Tratamento removido" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
