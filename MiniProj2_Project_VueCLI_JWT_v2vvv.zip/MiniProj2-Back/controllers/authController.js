const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const config = require("../config/config");

exports.register = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: "username e password são obrigatórios" });

    const existing = await User.findOne({ username });
    if (existing) return res.status(400).json({ error: "username já existe" });

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);

    const user = new User({ username, passwordHash: hash });
    await user.save();
    res.status(201).json({ message: "Utilizador criado" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ error: "Credenciais inválidas" });

    const ok = await user.verifyPassword(password);
    if (!ok) return res.status(400).json({ error: "Credenciais inválidas" });

    const token = jwt.sign({ id: user._id, username: user.username, role: user.role }, config.jwtSecret, { expiresIn: "8h" });
    // set Authorization header to match original Postman flow
    res.set('Authorization', 'Bearer ' + token);
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
