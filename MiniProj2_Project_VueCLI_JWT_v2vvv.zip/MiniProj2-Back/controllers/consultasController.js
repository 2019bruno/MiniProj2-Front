const Consulta = require("../models/Consulta");

exports.getAll = async (req, res) => {
  try {
    const consultas = await Consulta.find().sort({ data: -1 });
    res.json(consultas);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getById = async (req, res) => {
  try {
    const consulta = await Consulta.findById(req.params.id);
    if (!consulta) return res.status(404).json({ error: "Consulta não encontrada" });
    res.json(consulta);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.create = async (req, res) => {
  try {
    const consulta = new Consulta(req.body);
    await consulta.save();
    res.status(201).json(consulta);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const consulta = await Consulta.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!consulta) return res.status(404).json({ error: "Consulta não encontrada" });
    res.json(consulta);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    await Consulta.findByIdAndDelete(req.params.id);
    res.json({ message: "Consulta removida" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
