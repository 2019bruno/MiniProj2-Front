# MiniProj2-Back (Exemplo fictício) - com JWT

## Setup
1. Instalar Node.js
2. Instalar MongoDB e garantir que `mongod` está a correr (padrão: mongodb://localhost:27017)
3. `cd MiniProj2-Back`
4. `npm install`
5. Criar a base de dados `test` ou usar Studio 3T para copiar collections do servidor remoto conforme enunciado.
6. Para criar o utilizador admin por omissão execute:
   `node seedAdmin.js`
7. `npm run start` ou `npm run dev` (nodemon)

## Notas sobre autenticação
- POST /auth/register
- POST /auth/login  -> retorna { token } e também adiciona header Authorization: Bearer <token>
- Para todos os endpoints abaixo é necessário enviar o header: Authorization: Bearer <token>

## Endpoints principais
- GET /animals  (retorna os "clientes" como exemplos de animais)
- GET /clientes
- POST /clientes
- PUT /clientes/:id
- DELETE /clientes/:id

- GET /consultas
- POST /consultas
- PUT /consultas/:id
- DELETE /consultas/:id

- GET /tratamentos
- POST /tratamentos
- PUT /tratamentos/:id
- DELETE /tratamentos/:id
