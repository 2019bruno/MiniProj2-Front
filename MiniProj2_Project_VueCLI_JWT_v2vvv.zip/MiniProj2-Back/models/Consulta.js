const mongoose = require("mongoose");

const ConsultaSchema = new mongoose.Schema({
  animalId: { type: String, required: true },
  clienteId: { type: mongoose.Schema.Types.ObjectId, ref: "Cliente", required: true },
  data: { type: Date, required: true },
  descricao: { type: String }
}, { timestamps: true });

module.exports = mongoose.model("Consulta", ConsultaSchema);
