const mongoose = require("mongoose");

const TratamentoSchema = new mongoose.Schema({
  consultaId: { type: mongoose.Schema.Types.ObjectId, ref: "Consulta", required: true },
  tipo: { type: String, required: true },
  custo: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model("Tratamento", TratamentoSchema);
